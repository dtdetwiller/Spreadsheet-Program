﻿// Authors: Daniel Detwiller & Warren Kidman
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SpreadsheetGUI
{
    /// <summary>
    /// Keeps track of how many top-level forms are running
    /// </summary>
    class SpreadsheetGUIApplicationContext : ApplicationContext
    {
        /// <summary>
        /// Number of open spreadsheet forms
        /// </summary>
        private int formCount = 0;
        /// <summary>
        /// Singleton ApplicationContext
        /// </summary>
        private static SpreadsheetGUIApplicationContext appContext;

        /// <summary>
        /// Private constructor for singleton pattern
        /// </summary>
        private SpreadsheetGUIApplicationContext()
        {
        }

        /// <summary>
        /// Returns the one SpreadsheetGUIApplicationContext.
        /// </summary>
        public static SpreadsheetGUIApplicationContext getAppContext()
        {
            if (appContext == null)
                appContext = new SpreadsheetGUIApplicationContext();

            return appContext;
        }

        /// <summary>
        /// Runs the spreadsheet form.
        /// </summary>
        public void RunForm(Form form)
        {
            // Adds 1 to the number of forms running.
            formCount++;
            // When this form closes, we want to find out
            form.FormClosed += (o, e) => { if (--formCount <= 0) ExitThread(); };
            // Run the form
            form.Show();
        }

    }


    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // This makes it so that the program is not blurry and the format is not off.
            if (Environment.OSVersion.Version.Major >= 6)
                SetProcessDPIAware();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Start an application context and run one form inside it
            SpreadsheetGUIApplicationContext appContext = SpreadsheetGUIApplicationContext.getAppContext();
            appContext.RunForm(new SpreadsheetForm());
            Application.Run(appContext);
        }

        // Used to make program crisp
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();
    }
}