﻿README TEXT FILE FOR PS6: CS 3500
WRITTEN BY: Warren Kidman / Daniel Detwiller
SUBMISSION DATE: October 4, 2019

PS6 - Program.cs

SUMMARY:
- Program.cs simply allows for running forms, keeps track of open forms etc.
- Used Program.cs file from PS6Skeleton

PS6 - Form1.cs

SUMMARY:
- Form1.cs is the program that:
	- Implements Buttons, Labels, Textboxes for the SpreadSheetPanel GUI.
	- Takes in cell contents, evalates, and ouputs results in the GUI.
	- Allows user to creat muliple forms, save and open forms.
	- Takes in mouse-events, and arrow-key and enter-key presses.
- In short: Form1 allows the user to interact with the GUI


DESIGN:
- SEP 29: Intial commit:
	- Copied over Program.cs from PS6Sketon
	- Added SpreadSheet object into Form1.
		- This is what will represent the spreadsheet and all of its cells.
	- Added References to library file.

- SEP 30:
	- Fixed issue with references
	- Added all required labels and text boxes to the spreadsheetgui
	- Added update method that changed all cells referencing a cell (if that cell changed)
	- Implemented Open, Save, and New file menu.
	- Implemented method that converts row/col to cell notation and vise-versa

- OCT 2:
	- Changed save file menu button, added a save as option
		- Instead of always asking what the user wanted to save the file as, now if the file is the same
		  then save will just automatically save with no dialog box.
		- Added a small label that pops up, reads "SAVED" in dark green.
	- Added 'Nightmode' feture in the edit menu at the top of the spreadsheet.
		- Nightmode can be turned on and off in the menu.
		- Selecting on will change the spreadsheetpanel cell color to a dark grey and the text and lines
		  to a light grey. 
		- Also changes the color of the Enter button, all the labels and textboxes.
		- Turning Nightmode off reverts the spreadsheet panel to its default colors.

- OCT 3:
	- Now when the program is run, the arrow keys allow for changing selected cell.
		- Before, the content box need to be clicked before this feature would work.
	- Fixed problem with anchors.
	- Finalized Nightmode, needed alot of repetive code the change the color of all the different.
	  menues, labels, buttons, etc.
	- Cleaned up code, moved methods around in more organized manner.

LIBRARYS:
- PS2 Library has not been updated since submission to gradescope
- PS3 Library has not been updated since PS4 submission.
- PS4/5 Library updated:
		- Save method in PS5 fixed so name and content werent mixed up. 
		- Added a catch XMLException.
	
NOTE TO GRADER:
- Had to edit the SpreadsheetPanel dll in order to do NightMode (Additional Feature).